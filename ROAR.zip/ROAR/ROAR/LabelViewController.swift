//
//  LabelViewController.swift
//  ROAR
//
//  Created by FSE394 on 4/21/22.
//

import UIKit

class LabelViewController: UIViewController {

    @IBOutlet weak var userLabel: UILabel!
    var text: String?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if text != nil {
            userLabel.text = text
        }
       
    }
    



}
