//
//  ViewController.swift
//  ROAR
//
//  Created by FSE394 on 4/14/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var enterUser: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func buttonpressedUSER(_ sender: Any) {
        let controller = storyboard?.instantiateViewController(identifier:"LabelVC") as! LabelViewController
        controller.text = enterUser.text
        controller.modalPresentationStyle = .fullScreen
        present(controller, animated: true, completion: nil)
    }
    
    



    
    


}

