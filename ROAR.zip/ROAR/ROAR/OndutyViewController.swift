//
//  OndutyViewController.swift
//  ROAR
//
//  Created by FSE394 on 4/20/22.
//

import UIKit

class OndutyViewController: UIViewController {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

}
