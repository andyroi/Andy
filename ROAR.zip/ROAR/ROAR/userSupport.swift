//
//  userSupport.swift
//  ROAR
//
//  Created by FSE394 on 4/19/22.
//

import UIKit

class userSupport: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }

}
